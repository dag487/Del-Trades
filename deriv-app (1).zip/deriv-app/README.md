# Deriv Trader (Vercel)

Static app + two serverless functions. Features: live ticks chart, manual trading, simple bot, account/portfolio/history.

## Setup
1. Register a **PAT-type** app at https://developers.deriv.com (legacy App IDs do not work) and create a PAT with `trade` scope.
2. Deploy: `npx vercel` (or push to GitHub and import in Vercel).
3. In Vercel > Settings > Environment Variables add `DERIV_APP_ID` = your new App ID, then redeploy.
4. Open the site, paste your PAT, pick a **demo** account first.

Your PAT stays in browser memory only and is sent just to your own /api routes.
