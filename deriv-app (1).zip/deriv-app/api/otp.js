// Vercel serverless function: exchanges a Deriv PAT/JWT for an authenticated WebSocket URL.
// Keeps your App ID server-side and avoids browser CORS issues.
module.exports = async (req, res) => {
  if (req.method !== 'POST') return res.status(405).json({ error: 'POST only' });
  const { token, accountId } = req.body || {};
  if (!token || !accountId) return res.status(400).json({ error: 'token and accountId required' });
  try {
    const r = await fetch(
      `https://api.derivws.com/trading/v1/options/accounts/${encodeURIComponent(accountId)}/otp`,
      { method: 'POST', headers: { Authorization: `Bearer ${token}`, 'Deriv-App-ID': process.env.DERIV_APP_ID || '' } }
    );
    res.status(r.status).json(await r.json().catch(() => ({})));
  } catch (e) { res.status(502).json({ error: String(e) }); }
};
