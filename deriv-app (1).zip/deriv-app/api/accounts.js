// Vercel serverless function: lists the Deriv accounts for a PAT/JWT.
module.exports = async (req, res) => {
  if (req.method !== 'POST') return res.status(405).json({ error: 'POST only' });
  const { token } = req.body || {};
  if (!token) return res.status(400).json({ error: 'token required' });
  try {
    const r = await fetch('https://api.derivws.com/trading/v1/options/accounts', {
      headers: { Authorization: `Bearer ${token}`, 'Deriv-App-ID': process.env.DERIV_APP_ID || '' }
    });
    res.status(r.status).json(await r.json().catch(() => ({})));
  } catch (e) { res.status(502).json({ error: String(e) }); }
};
